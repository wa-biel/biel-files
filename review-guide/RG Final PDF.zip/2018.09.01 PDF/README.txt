Reviewers' Guide (September 2018)

GENERAL USAGE NOTES
=====================

- The Reviewers' Guide is a collection of documents to help local churches check the accuracy and naturalness of    their Bible translation.

- Included with the Reviewers' Guide are documents called Application Guides. If a someone would like to use the   Reviewers' Guide as a teaching tool, the Application Guide can be used to help Christians apply biblical truths to   their lives.

- The Reviewers' Guide will be updated every few months. Visit bibleineverylanguage.org to ensure that you have the   latest version.
------------------------------------------------------------------------------------------------------------------

Opening the Reviewers' Guide folder
---------------------------------------

- When you download the Reviewers' Guide folder from bibleineverylanguage.org, the folder will be in .zip format.   You will need a program such as Winzip, WinRar, or 7-Zip to unzip the file. 

- Once the folder is unzipped, do not move any of the files out of the folder. Some of the documents have links to   other documents within the folder. If you remove the file from the folder, the links will no longer work.

==================================================================================================================


If you have any questions or would like to report an issue you found in the Reviewers' Guide we can be contacted at:

E-mail: translation_services@wycliffeassociates.org

Wycliffe Associates